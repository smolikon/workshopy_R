# Klini na Source napravo nahoře a nech si balíčky nainstalovat, ne se všemi budeme pracovat na 1. setkání

# Děkuji, to je prozatím vše  

install.packages(c("tidyverse", "openxlsx", "janitor", "RCzechia", "skimr", 
                   "stats", "reschola", "czso", "tmap", "sf", "rmarkdown", "Rcpp"))

